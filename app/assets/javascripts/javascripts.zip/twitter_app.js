window.TwitterApp = {
  Models: {},
  Collections: {},
  Views: {},
  Routers: {},
  initialize: function() {
    var router;
    console.log('Backbone Initialize!');
    router = new TwitterApp.Routers.Users();
    return Backbone.history.start({
      pushState: true
    });
  }
};

$(document).ready(function() {
  return TwitterApp.initialize();
});

$(document).on('page:load', function() {
  Backbone.history.stop();
  return TwitterApp.initialize();
});
