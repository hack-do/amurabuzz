TwitterApp.Models.User = Backbone.Model.extend({
	urlRoot : "bb_show"
});
