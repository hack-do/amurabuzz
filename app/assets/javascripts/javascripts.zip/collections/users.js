TwitterApp.Collections.Users = Backbone.Collection.extend({

  model: TwitterApp.Models.User,
  url : "bb_index"

});
