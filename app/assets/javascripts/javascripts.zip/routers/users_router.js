TwitterApp.Routers.Users = Backbone.Router.extend({

	 initialize: function() {
	 	console.log('Router initialized');
	    this.users = new TwitterApp.Collections.Users();
	    console.log("Collections initialized" + this.users);
	    this.userPromise = this.users.fetch({
	      complete: function(xhr ,status){
				console.log('promise done');
				//console.log(xhr.responseJSON);
		     
		      this.usersIndexView = new TwitterApp.Views.UsersIndex({
			      title: "All Users",
			      users: xhr.responseJSON
		    	});
			
			this.usersIndexView.render();
			console.log("View Rendered " + this.usersIndexView.el);
	      }
	    });
	    
	    
	  },

	  routes: {
	    '': 'root',
	    'x': 'test',
	    'home/me': 'home',
	    'backbone': 'index',
	    'backbone/show/:id': 'show',
	    'backbone/edit/:id': 'edit',
	    'backbone/delete/:id': 'delete'
	  },

	  root: function() {
	    return console.log('root path');
	  },

	  test: function() {
	    return console.log('test path');
	  },
	  
	  index: function() {
	    console.log('index path');
	    //$.when(this.userPromise).then(function() {
	 //    this.userPromise.complete(function () {
	 //      	console.log('promise done');
		     
		//       this.usersIndexView = new TwitterApp.Views.UsersIndex({
		// 	      name: "Vineet",
		// 	      users: this.users
		//     	});
			
		// 	console.log("View instantiated " + this.usersIndexView);

		// 	this.usersIndexView.render();

		// 	console.log("View Rendered " + this.usersIndexView.el);

		// });
	  
	  },

	  show: function(id) {
	    return console.log('show path ' + id);
	  },
	  edit: function() {
	    return console.log('edit path');
	  },
	  "delete": function() {
	    return console.log('delete path');
	  }
	
});
