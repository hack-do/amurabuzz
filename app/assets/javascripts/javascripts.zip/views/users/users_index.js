TwitterApp.Views.UsersIndex = Backbone.View.extend({

	  template: JST['users/index'],

	  initialize: function(options) {
	    console.log("user view initialized");
	    return this.options = options;
	  },

	  render: function() {
	    var markup;
	    console.log(" view render function ");
	    console.log(this.options.users);
	    markup = '<div><p>' + this.options.title + '</p>' + '<table>';
	    // this.options.users.each(function(user) {
	    //   console.log(user);
	    // });
		// for(int i = 0; i < this.options.name.size(); i++){
  //     		console.log(this.options.name.get(i));
		// }


		$.each(this.options.users, function(i, item) {
		    console.log(item);
		    markup += '<tr><td>' + item.email + '</td></tr>';
		});

		markup += '</table></div>'

	    this.$el.html(markup);
	    $('#all_users_backbone').html(markup);
	    return this;
	  }

});
